#include <filesystem>
#include "ProcessInfo.h"
#include "bussdownrolly.h"

bool Start(ProcessInfo processInfo, const std::filesystem::path& filePath)
{
    bustdownrolly bustdownrolly(processInfo, filePath);
    bustdownrolly.inject();
    return EXIT_SUCCESS;
}